var searchData=
[
  ['pi_5fcontroller',['PI_controller',['../_current_control_8h.html#af15be4bf8772044edad3aac0661bc2fb',1,'CurrentControl.c']]],
  ['pid_5fcontroller',['PID_Controller',['../_position_control_8h.html#ae9c5d5742402a141a717b24a8a216287',1,'PositionControl.c']]],
  ['pid_5fgains',['PID_gains',['../struct_p_i_d__gains.html',1,'']]],
  ['positioncontrol_2eh',['PositionControl.h',['../_position_control_8h.html',1,'']]],
  ['pwm',['PWM',['../_utilities_8h.html#a1a6b6fb557d8d37d59700faf4e4c9167aef99a276e1f3b62b5df98acc27b38028',1,'Utilities.h']]],
  ['pwminit',['pwmInit',['../_motor_8h.html#a1c8ae46921c4ae7d57bd44dd994e10bd',1,'Motor.c']]]
];
