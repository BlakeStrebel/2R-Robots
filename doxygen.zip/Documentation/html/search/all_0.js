var searchData=
[
  ['actpos',['actPos',['../structmotor__control__data.html#a15da9ec28fdeb23649bdf9755b82f229',1,'motor_control_data']]],
  ['ad0_5fread',['AD0_read',['../_current_control_8h.html#a93267f78ddf20170576a97f752c41670',1,'CurrentControl.c']]],
  ['adc_2eh',['Adc.h',['../_adc_8h.html',1,'']]],
  ['adccurrentread',['adcCurrentRead',['../_adc_8h.html#a10a122657b8f802a6931e2bd8732289e',1,'Adc.c']]],
  ['adcinit',['adcInit',['../_adc_8h.html#afd645b17cf0581bcaa22c56011c775e4',1,'Adc.c']]],
  ['adcread',['adcRead',['../_adc_8h.html#abe02cc201baa3f3c88b6cfe688d13cb2',1,'Adc.c']]],
  ['anglestocounts',['anglesToCounts',['../_encoder_8h.html#a9e427f3b5834b74b7302b7f36745c7b1',1,'Encoder.c']]]
];
