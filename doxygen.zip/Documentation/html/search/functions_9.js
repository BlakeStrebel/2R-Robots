var searchData=
[
  ['pi_5fcontroller',['PI_controller',['../_current_control_8h.html#af15be4bf8772044edad3aac0661bc2fb',1,'CurrentControl.c']]],
  ['pid_5fcontroller',['PID_Controller',['../_position_control_8h.html#ae9c5d5742402a141a717b24a8a216287',1,'PositionControl.c']]],
  ['pwminit',['pwmInit',['../_motor_8h.html#a1c8ae46921c4ae7d57bd44dd994e10bd',1,'Motor.c']]]
];
