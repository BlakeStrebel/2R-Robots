var searchData=
[
  ['get_5fcounts',['get_counts',['../_current_control_8h.html#a0da5d7ad7c18cafb47a64f4bd3848736',1,'CurrentControl.c']]],
  ['get_5fcurrent_5fgains',['get_current_gains',['../_current_control_8h.html#a1387f079055f48a6edf850a0f05e5218',1,'CurrentControl.c']]],
  ['get_5fma',['get_mA',['../_current_control_8h.html#a45dbdfe1412c710e7ff452fe7c61f7ed',1,'CurrentControl.c']]],
  ['get_5frefpos',['get_refPos',['../_utilities_8h.html#a95d42f6612b70ed6839a907ccbee29e8',1,'Utilities.c']]],
  ['getdesiredangle',['getDesiredAngle',['../_position_control_8h.html#a7d8f30e709500ee488ebe3ddb18d68b4',1,'PositionControl.c']]],
  ['getmode',['getMODE',['../_utilities_8h.html#a19e5b0661a8f7acb8c2a975a4c84c0aa',1,'Utilities.c']]],
  ['getmotor1halls',['getmotor1HALLS',['../_motor_8h.html#a0b350d90bf46d3ae9e0c2678db6ab0b2',1,'Motor.c']]],
  ['getmotor1pwm',['getmotor1PWM',['../_motor_8h.html#aa2c42019652e402afdfa5330e84a917e',1,'Motor.c']]],
  ['getmotor2halls',['getmotor2HALLS',['../_motor_8h.html#a53f843252b562efc951e13b6db10ef22',1,'Motor.c']]],
  ['getmotor2pwm',['getmotor2PWM',['../_motor_8h.html#a25d33861bd682d093b24c60f2cbabf20',1,'Motor.c']]],
  ['getmotorpwm',['getMotorPWM',['../_position_control_8h.html#ab88d13920601fd59de9af910521873aa',1,'PositionControl.c']]],
  ['getn',['getN',['../_utilities_8h.html#ad100531ac5483b0915dc7ebf2e6f3a3d',1,'Utilities.c']]],
  ['getpositiongains',['getPositionGains',['../_position_control_8h.html#a376eb9b05453f76c96690363f3353e6f',1,'PositionControl.c']]],
  ['gettime',['getTime',['../_system_8h.html#a606dc97cf5056886cfd30122ce54709c',1,'System.c']]]
];
