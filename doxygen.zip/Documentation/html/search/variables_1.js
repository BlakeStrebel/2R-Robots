var searchData=
[
  ['refpos',['refPos',['../structmotor__control__data.html#ae6513e1fa4febfae80aa33ecabb99dbc',1,'motor_control_data']]]
];
