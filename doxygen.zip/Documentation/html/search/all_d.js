var searchData=
[
  ['send_5fdata',['send_data',['../_utilities_8h.html#aa8061654c0af0c3c3fac9e63ed7eaed6',1,'Utilities.c']]],
  ['sensorupdate',['sensorUpdate',['../r2r_8c.html#ad22b938bbd9c44b3de841391716d46b9',1,'sensorUpdate(void):&#160;r2r.c'],['../r2r_8h.html#a4ecaa31712e652b0a1cc2d8fc212e2f5',1,'sensorUpdate() extern void customTimersInit(void):&#160;r2r.c']]],
  ['set_5fcurrent_5fgains',['set_current_gains',['../_current_control_8h.html#afdcd89e75250a253db7555d550f2b7ad',1,'CurrentControl.c']]],
  ['setadcmux',['setADCMux',['../_adc_8h.html#ab07c8a54a14148ee47eef30ea3baa661',1,'Adc.c']]],
  ['setcurrent',['setCurrent',['../_current_control_8h.html#a991b6533f7e203f97b3a2da6cac50476',1,'CurrentControl.c']]],
  ['setdecogging',['setDecogging',['../_position_control_8h.html#a975ab84b3adffb7d1d9f7f3b9c8ae8c2',1,'PositionControl.c']]],
  ['setdesiredangle',['setDesiredAngle',['../_position_control_8h.html#abf3123e6b311e64da34906bf1ac73ed8',1,'PositionControl.c']]],
  ['setmode',['setMODE',['../_utilities_8h.html#af4c5a7352334b805d0c36e3b495d0a16',1,'Utilities.c']]],
  ['setmotorzero',['setMotorZero',['../_encoder_8h.html#a3696aee4ef23091df2e085cbc11404b9',1,'Encoder.c']]],
  ['setn',['setN',['../_utilities_8h.html#a879808dbc63ea605a96bed9d93441d3f',1,'Utilities.c']]],
  ['setnclient',['setNclient',['../_utilities_8h.html#a28222caa228cb42e3dd503f611a431ff',1,'Utilities.c']]],
  ['setpositiongains',['setPositionGains',['../_position_control_8h.html#a2f066ae1c628a1a02b3fe5a2f1efb724',1,'PositionControl.c']]],
  ['setpositionpid',['setPositionPID',['../_position_control_8h.html#ab8aff07bbb708864a0aa8ccc93dcc3aa',1,'PositionControl.c']]],
  ['shutdownnow',['shutdownNow',['../_motor_8h.html#a3736cf7b742152f2787804fad1c999e2',1,'Motor.c']]],
  ['sysinit',['sysInit',['../_system_8h.html#a9708de954e135b89af84d9d82b552667',1,'System.c']]],
  ['system_2eh',['System.h',['../_system_8h.html',1,'']]]
];
