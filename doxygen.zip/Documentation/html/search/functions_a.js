var searchData=
[
  ['r2rdefaultinit',['r2rDefaultInit',['../r2r_8c.html#af06127bca89306e7f9af0ea36f162ca0',1,'r2rDefaultInit(void):&#160;r2r.c'],['../r2r_8h.html#af06127bca89306e7f9af0ea36f162ca0',1,'r2rDefaultInit(void):&#160;r2r.c']]],
  ['readmotor1angle',['readMotor1Angle',['../_encoder_8h.html#a3158f6a637c9f6e10084501a81431581',1,'Encoder.h']]],
  ['readmotor2angle',['readMotor2Angle',['../_encoder_8h.html#acf5c46f542d35b78a92a1cefac802888',1,'Encoder.h']]],
  ['readmotorangle',['readMotorAngle',['../_encoder_8h.html#a1fce0320ba0ca0fe37d3b391a47adef0',1,'Encoder.c']]],
  ['readmotoranglerelative',['readMotorAngleRelative',['../_encoder_8h.html#a4cc507f6297a7e84cdfb4cec6e5d7749',1,'Encoder.c']]],
  ['readmotorcounts',['readMotorCounts',['../_encoder_8h.html#a1006888f548e8061d0e40f2a10924804',1,'Encoder.c']]],
  ['readmotorrad',['readMotorRad',['../_encoder_8h.html#a2a54dab75f7a407ae90b1b2c931c0147',1,'Encoder.c']]],
  ['readmotorradrelative',['readMotorRadRelative',['../_encoder_8h.html#ab294e6902489fe3002becb309a24be1c',1,'Encoder.c']]],
  ['readmotorraw',['readMotorRaw',['../_encoder_8h.html#a682581003a8423d40a2bb2dc462877da',1,'Encoder.c']]],
  ['readmotorrawrelative',['readMotorRawRelative',['../_encoder_8h.html#a772612423c09160fb30903910645dd71',1,'Encoder.c']]],
  ['readmotorspeed',['readMotorSpeed',['../_encoder_8h.html#acd3dc7f7a6dc84b5dba607f76092acee',1,'Encoder.c']]],
  ['reset_5fcurrent_5ferror',['reset_current_error',['../_current_control_8h.html#a7158c18c7941b14c7eac79a8c4f6692e',1,'CurrentControl.c']]],
  ['resetcontrollererror',['resetControllerError',['../_position_control_8h.html#a95e5f03d55fba3d858adbcea6afa9315',1,'PositionControl.c']]]
];
