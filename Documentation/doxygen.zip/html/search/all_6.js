var searchData=
[
  ['hold',['HOLD',['../_utilities_8h.html#a1a6b6fb557d8d37d59700faf4e4c9167a9cfa27b414cab750fb14ec07cdf5cf6a',1,'Utilities.h']]]
];
