var searchData=
[
  ['get_5fdesired_5fangle',['get_desired_angle',['../_control_8h.html#a5b86db5b678ee3f8de68b9d2d85a8e1e',1,'Control.c']]],
  ['get_5fmotor_5fpwm',['get_motor_pwm',['../_control_8h.html#a7e15715f934ac02744e6af24bf61d696',1,'Control.c']]],
  ['get_5fposition_5fgains',['get_position_gains',['../_control_8h.html#a881cd4b090a428bf27f7e3b4a88b6e80',1,'Control.c']]],
  ['get_5frefpos',['get_refPos',['../_utilities_8h.html#a95d42f6612b70ed6839a907ccbee29e8',1,'Utilities.c']]],
  ['getmode',['getMODE',['../_utilities_8h.html#a19e5b0661a8f7acb8c2a975a4c84c0aa',1,'Utilities.c']]],
  ['getn',['getN',['../_utilities_8h.html#ad100531ac5483b0915dc7ebf2e6f3a3d',1,'Utilities.c']]],
  ['gpioinit',['gpioInit',['../_system_8h.html#adab76f1253da89e657056817a3a9a11a',1,'System.c']]]
];
