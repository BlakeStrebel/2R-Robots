var searchData=
[
  ['r2r_2ec',['r2r.c',['../r2r_8c.html',1,'']]],
  ['r2r_2eh',['r2r.h',['../r2r_8h.html',1,'']]],
  ['r2rdefaultinit',['r2rDefaultInit',['../r2r_8c.html#af06127bca89306e7f9af0ea36f162ca0',1,'r2rDefaultInit(void):&#160;r2r.c'],['../r2r_8h.html#af06127bca89306e7f9af0ea36f162ca0',1,'r2rDefaultInit(void):&#160;r2r.c']]],
  ['readmotor1angle',['readMotor1Angle',['../_encoder_8c.html#a3158f6a637c9f6e10084501a81431581',1,'readMotor1Angle(void):&#160;Encoder.c'],['../_encoder_8h.html#a3158f6a637c9f6e10084501a81431581',1,'readMotor1Angle(void):&#160;Encoder.c']]],
  ['readmotor1anglerelative',['readMotor1AngleRelative',['../_encoder_8c.html#adadde057f0a039eba73600bd55a68048',1,'readMotor1AngleRelative(void):&#160;Encoder.c'],['../_encoder_8h.html#adadde057f0a039eba73600bd55a68048',1,'readMotor1AngleRelative(void):&#160;Encoder.c']]],
  ['readmotor1raw',['readMotor1Raw',['../_encoder_8c.html#a41631dbb83071f47c7e30a38b05f269c',1,'readMotor1Raw(void):&#160;Encoder.c'],['../_encoder_8h.html#a41631dbb83071f47c7e30a38b05f269c',1,'readMotor1Raw(void):&#160;Encoder.c']]],
  ['readmotor1rawrelative',['readMotor1RawRelative',['../_encoder_8c.html#a6c979bc3fe5ea8aff136af160338640f',1,'readMotor1RawRelative(void):&#160;Encoder.c'],['../_encoder_8h.html#a6c979bc3fe5ea8aff136af160338640f',1,'readMotor1RawRelative(void):&#160;Encoder.c']]],
  ['readmotor2angle',['readMotor2Angle',['../_encoder_8c.html#acf5c46f542d35b78a92a1cefac802888',1,'readMotor2Angle(void):&#160;Encoder.c'],['../_encoder_8h.html#acf5c46f542d35b78a92a1cefac802888',1,'readMotor2Angle(void):&#160;Encoder.c']]],
  ['readmotor2anglerelative',['readMotor2AngleRelative',['../_encoder_8c.html#a8277b1c9a143a978685671b1a0c7f90d',1,'readMotor2AngleRelative(void):&#160;Encoder.c'],['../_encoder_8h.html#a8277b1c9a143a978685671b1a0c7f90d',1,'readMotor2AngleRelative(void):&#160;Encoder.c']]],
  ['readmotor2raw',['readMotor2Raw',['../_encoder_8c.html#ad2f5f86641346f94615d9962f214438a',1,'readMotor2Raw(void):&#160;Encoder.c'],['../_encoder_8h.html#ad2f5f86641346f94615d9962f214438a',1,'readMotor2Raw(void):&#160;Encoder.c']]],
  ['readmotor2rawrelative',['readMotor2RawRelative',['../_encoder_8c.html#a64bdccf53dabc69d335d5e7d53e5b31a',1,'readMotor2RawRelative(void):&#160;Encoder.c'],['../_encoder_8h.html#a64bdccf53dabc69d335d5e7d53e5b31a',1,'readMotor2RawRelative(void):&#160;Encoder.c']]],
  ['refpos',['refPos',['../structcontrol__data__t.html#a6ad7ecc535cbb0cd2070d49b0791f677',1,'control_data_t']]],
  ['reset_5fcurrent_5ferror',['reset_current_error',['../_current_control_8c.html#a7158c18c7941b14c7eac79a8c4f6692e',1,'reset_current_error(void):&#160;CurrentControl.c'],['../_current_control_8h.html#a7158c18c7941b14c7eac79a8c4f6692e',1,'reset_current_error(void):&#160;CurrentControl.c']]],
  ['resetmotor1rawrelative',['resetMotor1RawRelative',['../_encoder_8c.html#a51fa2168209218edff3cabcb2d2bbb2e',1,'resetMotor1RawRelative(void):&#160;Encoder.c'],['../_encoder_8h.html#a51fa2168209218edff3cabcb2d2bbb2e',1,'resetMotor1RawRelative(void):&#160;Encoder.c']]],
  ['resetmotor2rawrelative',['resetMotor2RawRelative',['../_encoder_8c.html#a99c3336d6e0ce560b4f0424dc8a091f9',1,'resetMotor2RawRelative(void):&#160;Encoder.c'],['../_encoder_8h.html#a99c3336d6e0ce560b4f0424dc8a091f9',1,'resetMotor2RawRelative(void):&#160;Encoder.c']]]
];
