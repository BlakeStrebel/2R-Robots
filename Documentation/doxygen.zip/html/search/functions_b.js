var searchData=
[
  ['uart0read',['UART0read',['../r2r_8c.html#acd1ca90dcd2d241c90316f670dfcc2eb',1,'UART0read(char *message, int maxLength):&#160;r2r.c'],['../r2r_8h.html#acd1ca90dcd2d241c90316f670dfcc2eb',1,'UART0read(char *message, int maxLength):&#160;r2r.c']]],
  ['uart0write',['UART0write',['../r2r_8c.html#aba58039e2e0b55260a188aedbc87d18b',1,'UART0write(const char *string):&#160;r2r.c'],['../r2r_8h.html#aba58039e2e0b55260a188aedbc87d18b',1,'UART0write(const char *string):&#160;r2r.c']]],
  ['uartinit',['uartInit',['../r2r_8c.html#a09a7a9ed4194733a7b753c3b795b1734',1,'uartInit(void):&#160;r2r.c'],['../r2r_8h.html#a09a7a9ed4194733a7b753c3b795b1734',1,'uartInit(void):&#160;r2r.c']]]
];
