var searchData=
[
  ['refpos',['refPos',['../structcontrol__data__t.html#a6ad7ecc535cbb0cd2070d49b0791f677',1,'control_data_t']]]
];
