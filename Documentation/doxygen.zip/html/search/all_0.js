var searchData=
[
  ['actpos',['actPos',['../structcontrol__data__t.html#a892c45389a98ba3bfc68972f71eaaf12',1,'control_data_t']]],
  ['ad0_5fread',['AD0_read',['../_current_control_8c.html#a93267f78ddf20170576a97f752c41670',1,'AD0_read(int mux):&#160;CurrentControl.c'],['../_current_control_8h.html#a93267f78ddf20170576a97f752c41670',1,'AD0_read(int mux):&#160;CurrentControl.c']]]
];
