var searchData=
[
  ['actpos',['actPos',['../structcontrol__data__t.html#a892c45389a98ba3bfc68972f71eaaf12',1,'control_data_t']]],
  ['adccurrentread',['adcCurrentRead',['../r2r_8c.html#a41ad272c8068a61857379f79abbe9a29',1,'adcCurrentRead():&#160;r2r.c'],['../r2r_8h.html#a10a122657b8f802a6931e2bd8732289e',1,'adcCurrentRead(void):&#160;r2r.c']]],
  ['adcinit',['adcInit',['../r2r_8c.html#a27c5e947cca4b8e98323253543557b23',1,'adcInit():&#160;r2r.c'],['../r2r_8h.html#afd645b17cf0581bcaa22c56011c775e4',1,'adcInit(void):&#160;r2r.c']]],
  ['adcread',['adcRead',['../r2r_8c.html#abe02cc201baa3f3c88b6cfe688d13cb2',1,'adcRead(void):&#160;r2r.c'],['../r2r_8h.html#abe02cc201baa3f3c88b6cfe688d13cb2',1,'adcRead(void):&#160;r2r.c']]]
];
