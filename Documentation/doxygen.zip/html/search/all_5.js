var searchData=
[
  ['get_5fcounts',['get_counts',['../_current_control_8c.html#a0da5d7ad7c18cafb47a64f4bd3848736',1,'get_counts(void):&#160;CurrentControl.c'],['../_current_control_8h.html#a0da5d7ad7c18cafb47a64f4bd3848736',1,'get_counts(void):&#160;CurrentControl.c']]],
  ['get_5fcurrent_5fgains',['get_current_gains',['../_current_control_8c.html#a1387f079055f48a6edf850a0f05e5218',1,'get_current_gains(void):&#160;CurrentControl.c'],['../_current_control_8h.html#a1387f079055f48a6edf850a0f05e5218',1,'get_current_gains(void):&#160;CurrentControl.c']]],
  ['get_5fma',['get_mA',['../_current_control_8c.html#a45dbdfe1412c710e7ff452fe7c61f7ed',1,'get_mA(void):&#160;CurrentControl.c'],['../_current_control_8h.html#a45dbdfe1412c710e7ff452fe7c61f7ed',1,'get_mA(void):&#160;CurrentControl.c']]],
  ['get_5frefpos',['get_refPos',['../_utilities_8c.html#a95d42f6612b70ed6839a907ccbee29e8',1,'get_refPos(int index, int motor):&#160;Utilities.c'],['../_utilities_8h.html#a95d42f6612b70ed6839a907ccbee29e8',1,'get_refPos(int index, int motor):&#160;Utilities.c']]],
  ['getmode',['getMODE',['../_utilities_8c.html#a19e5b0661a8f7acb8c2a975a4c84c0aa',1,'getMODE():&#160;Utilities.c'],['../_utilities_8h.html#a19e5b0661a8f7acb8c2a975a4c84c0aa',1,'getMODE():&#160;Utilities.c']]],
  ['getmotor1halls',['getmotor1HALLS',['../_motor_8c.html#a0b350d90bf46d3ae9e0c2678db6ab0b2',1,'getmotor1HALLS(void):&#160;Motor.c'],['../_motor_8h.html#a0b350d90bf46d3ae9e0c2678db6ab0b2',1,'getmotor1HALLS(void):&#160;Motor.c']]],
  ['getmotor1pwm',['getmotor1PWM',['../_motor_8c.html#aa2c42019652e402afdfa5330e84a917e',1,'getmotor1PWM(void):&#160;Motor.c'],['../_motor_8h.html#aa2c42019652e402afdfa5330e84a917e',1,'getmotor1PWM(void):&#160;Motor.c']]],
  ['getmotor2halls',['getmotor2HALLS',['../_motor_8c.html#a53f843252b562efc951e13b6db10ef22',1,'getmotor2HALLS(void):&#160;Motor.c'],['../_motor_8h.html#a53f843252b562efc951e13b6db10ef22',1,'getmotor2HALLS(void):&#160;Motor.c']]],
  ['getmotor2pwm',['getmotor2PWM',['../_motor_8c.html#a25d33861bd682d093b24c60f2cbabf20',1,'getmotor2PWM(void):&#160;Motor.c'],['../_motor_8h.html#a25d33861bd682d093b24c60f2cbabf20',1,'getmotor2PWM(void):&#160;Motor.c']]],
  ['getn',['getN',['../_utilities_8c.html#ad100531ac5483b0915dc7ebf2e6f3a3d',1,'getN(void):&#160;Utilities.c'],['../_utilities_8h.html#ad100531ac5483b0915dc7ebf2e6f3a3d',1,'getN(void):&#160;Utilities.c']]],
  ['gettime',['getTime',['../r2r_8c.html#a28c11ac72f44462ab5684a9bf4fae0d9',1,'getTime():&#160;r2r.c'],['../r2r_8h.html#a606dc97cf5056886cfd30122ce54709c',1,'getTime(void):&#160;r2r.c']]]
];
