var searchData=
[
  ['filtervalues',['filterValues',['../r2r_8c.html#a46f1498819aff67a1a241a655fea2bb1',1,'filterValues():&#160;r2r.c'],['../r2r_8h.html#a69727472048a870efca79e2305a477b5',1,'filterValues(void):&#160;r2r.c']]]
];
