var searchData=
[
  ['pi_5fcontroller',['PI_controller',['../_current_control_8c.html#af15be4bf8772044edad3aac0661bc2fb',1,'PI_controller(int motor, int reference, int actual):&#160;CurrentControl.c'],['../_current_control_8h.html#af15be4bf8772044edad3aac0661bc2fb',1,'PI_controller(int motor, int reference, int actual):&#160;CurrentControl.c']]],
  ['pwm',['PWM',['../_utilities_8h.html#a1a6b6fb557d8d37d59700faf4e4c9167aef99a276e1f3b62b5df98acc27b38028',1,'Utilities.h']]],
  ['pwminit',['pwmInit',['../_motor_8h.html#a1c8ae46921c4ae7d57bd44dd994e10bd',1,'Motor.h']]]
];
