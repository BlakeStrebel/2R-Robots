var searchData=
[
  ['control_5fdata_5ft',['control_data_t',['../structcontrol__data__t.html',1,'']]],
  ['control_5ferror',['control_error',['../structcontrol__error.html',1,'']]]
];
