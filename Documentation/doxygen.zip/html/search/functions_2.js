var searchData=
[
  ['currentread1',['currentRead1',['../r2r_8c.html#a18b7e8958a230c54f3fe5ac8bc24b24c',1,'currentRead1(void):&#160;r2r.c'],['../r2r_8h.html#a18b7e8958a230c54f3fe5ac8bc24b24c',1,'currentRead1(void):&#160;r2r.c']]],
  ['currentread2',['currentRead2',['../r2r_8c.html#abdb4ca825a07f76a89212240e43546ca',1,'currentRead2(void):&#160;r2r.c'],['../r2r_8h.html#abdb4ca825a07f76a89212240e43546ca',1,'currentRead2(void):&#160;r2r.c']]]
];
