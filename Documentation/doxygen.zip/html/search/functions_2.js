var searchData=
[
  ['counts_5fread',['counts_read',['../_current_control_8c.html#a3fcbe969c8ba545f99c2ad2581783e1b',1,'counts_read(void):&#160;CurrentControl.c'],['../_current_control_8h.html#a3fcbe969c8ba545f99c2ad2581783e1b',1,'counts_read(void):&#160;CurrentControl.c']]],
  ['currentcontrolinit',['currentControlInit',['../_current_control_8c.html#aee24c1cb239954c88299414a76d7ace0',1,'currentControlInit(void):&#160;CurrentControl.c'],['../_current_control_8h.html#aee24c1cb239954c88299414a76d7ace0',1,'currentControlInit(void):&#160;CurrentControl.c']]],
  ['currentcontrolinthandler',['CurrentControlIntHandler',['../_current_control_8c.html#a4138bb37174684f4f39588358ea02696',1,'CurrentControlIntHandler(void):&#160;CurrentControl.c'],['../_current_control_8h.html#a4138bb37174684f4f39588358ea02696',1,'CurrentControlIntHandler(void):&#160;CurrentControl.c']]],
  ['customtimersinit',['customTimersInit',['../r2r_8h.html#a77af04bd0735a3d7eb04200c61fc7812',1,'r2r.h']]]
];
