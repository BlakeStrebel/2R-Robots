var searchData=
[
  ['send_5fdata',['send_data',['../_utilities_8c.html#aa8061654c0af0c3c3fac9e63ed7eaed6',1,'send_data(void):&#160;Utilities.c'],['../_utilities_8h.html#aa8061654c0af0c3c3fac9e63ed7eaed6',1,'send_data(void):&#160;Utilities.c']]],
  ['set_5fcurrent_5fgains',['set_current_gains',['../_current_control_8c.html#afdcd89e75250a253db7555d550f2b7ad',1,'set_current_gains(void):&#160;CurrentControl.c'],['../_current_control_8h.html#afdcd89e75250a253db7555d550f2b7ad',1,'set_current_gains(void):&#160;CurrentControl.c']]],
  ['setadcmux',['setADCMux',['../_current_control_8c.html#ab07c8a54a14148ee47eef30ea3baa661',1,'setADCMux(int motor, int number):&#160;CurrentControl.c'],['../_current_control_8h.html#ab07c8a54a14148ee47eef30ea3baa661',1,'setADCMux(int motor, int number):&#160;CurrentControl.c']]],
  ['setcurrent',['setCurrent',['../_current_control_8c.html#a991b6533f7e203f97b3a2da6cac50476',1,'setCurrent(int motor, int u):&#160;CurrentControl.c'],['../_current_control_8h.html#a991b6533f7e203f97b3a2da6cac50476',1,'setCurrent(int motor, int u):&#160;CurrentControl.c']]],
  ['setmode',['setMODE',['../_utilities_8c.html#af4c5a7352334b805d0c36e3b495d0a16',1,'setMODE(mode newMODE):&#160;Utilities.c'],['../_utilities_8h.html#af4c5a7352334b805d0c36e3b495d0a16',1,'setMODE(mode newMODE):&#160;Utilities.c']]],
  ['setn',['setN',['../_utilities_8c.html#acba07f8eaf5cdce3760657cfd53c35b8',1,'setN(void):&#160;Utilities.c'],['../_utilities_8h.html#acba07f8eaf5cdce3760657cfd53c35b8',1,'setN(void):&#160;Utilities.c']]],
  ['setnclient',['setNclient',['../_utilities_8c.html#a28222caa228cb42e3dd503f611a431ff',1,'setNclient(int n):&#160;Utilities.c'],['../_utilities_8h.html#a28222caa228cb42e3dd503f611a431ff',1,'setNclient(int n):&#160;Utilities.c']]],
  ['sysinit',['sysInit',['../r2r_8c.html#a9708de954e135b89af84d9d82b552667',1,'sysInit(void):&#160;r2r.c'],['../r2r_8h.html#a9708de954e135b89af84d9d82b552667',1,'sysInit(void):&#160;r2r.c']]]
];
