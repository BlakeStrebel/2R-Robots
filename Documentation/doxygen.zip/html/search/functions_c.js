var searchData=
[
  ['tempread1',['tempRead1',['../r2r_8c.html#a95fdbb62322ad9460cc8dd72a50fa3ab',1,'tempRead1(void):&#160;r2r.c'],['../r2r_8h.html#a95fdbb62322ad9460cc8dd72a50fa3ab',1,'tempRead1(void):&#160;r2r.c']]],
  ['tempread2',['tempRead2',['../r2r_8c.html#a3f4089fb4d4ec13a11fa01fa6b671795',1,'tempRead2(void):&#160;r2r.c'],['../r2r_8h.html#a3f4089fb4d4ec13a11fa01fa6b671795',1,'tempRead2(void):&#160;r2r.c']]]
];
