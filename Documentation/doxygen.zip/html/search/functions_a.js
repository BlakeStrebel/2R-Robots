var searchData=
[
  ['r2rdefaultinit',['r2rDefaultInit',['../r2r_8c.html#af06127bca89306e7f9af0ea36f162ca0',1,'r2rDefaultInit(void):&#160;r2r.c'],['../r2r_8h.html#af06127bca89306e7f9af0ea36f162ca0',1,'r2rDefaultInit(void):&#160;r2r.c']]],
  ['readmotor1angle',['readMotor1Angle',['../_encoder_8h.html#a3158f6a637c9f6e10084501a81431581',1,'Encoder.c']]],
  ['readmotor1anglerelative',['readMotor1AngleRelative',['../_encoder_8h.html#adadde057f0a039eba73600bd55a68048',1,'Encoder.c']]],
  ['readmotor1raw',['readMotor1Raw',['../_encoder_8h.html#a41631dbb83071f47c7e30a38b05f269c',1,'Encoder.c']]],
  ['readmotor1rawrelative',['readMotor1RawRelative',['../_encoder_8h.html#a6c979bc3fe5ea8aff136af160338640f',1,'Encoder.c']]],
  ['readmotor1speed',['readMotor1Speed',['../_encoder_8h.html#a32d76f5feb48e875eddaa9c1dbd19276',1,'Encoder.c']]],
  ['readmotor2angle',['readMotor2Angle',['../_encoder_8h.html#acf5c46f542d35b78a92a1cefac802888',1,'Encoder.c']]],
  ['readmotor2anglerelative',['readMotor2AngleRelative',['../_encoder_8h.html#a8277b1c9a143a978685671b1a0c7f90d',1,'Encoder.c']]],
  ['readmotor2raw',['readMotor2Raw',['../_encoder_8h.html#ad2f5f86641346f94615d9962f214438a',1,'Encoder.c']]],
  ['readmotor2rawrelative',['readMotor2RawRelative',['../_encoder_8h.html#a64bdccf53dabc69d335d5e7d53e5b31a',1,'Encoder.c']]],
  ['readmotor2speed',['readMotor2Speed',['../_encoder_8h.html#a6391115b4eaa017554396e9c0bd81ac4',1,'Encoder.c']]],
  ['reset_5fcontroller_5ferror',['reset_controller_error',['../_control_8h.html#adf80f17bfeea7e84613a2fb9142dfbc4',1,'Control.c']]],
  ['reset_5fpos',['reset_pos',['../_control_8h.html#a68b7b6c3193b76e37c547f3448c6fcbb',1,'Control.h']]]
];
