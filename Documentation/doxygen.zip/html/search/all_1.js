var searchData=
[
  ['boundint',['boundInt',['../_utilities_8c.html#a88ade88617e9bae6f82653ec6d6470a1',1,'boundInt(int a, int n):&#160;Utilities.c'],['../_utilities_8h.html#a88ade88617e9bae6f82653ec6d6470a1',1,'boundInt(int a, int n):&#160;Utilities.c']]],
  ['buffer_5fempty',['buffer_empty',['../_utilities_8c.html#add3b6ddfe2455ef3b350799c0bb1391a',1,'buffer_empty():&#160;Utilities.c'],['../_utilities_8h.html#a7ee932fa1bdc8820ae0479fa64cf1e01',1,'buffer_empty(void):&#160;Utilities.c']]],
  ['buffer_5ffull',['buffer_full',['../_utilities_8c.html#a4d3fecfd260112b4979ccab4aa21c53d',1,'buffer_full():&#160;Utilities.c'],['../_utilities_8h.html#ab06f20d652c9a1f51223495940f71ff0',1,'buffer_full(void):&#160;Utilities.c']]],
  ['buffer_5fread_5fincrement',['buffer_read_increment',['../_utilities_8c.html#ab2a010861366a7ee08860c011e3c1b55',1,'buffer_read_increment():&#160;Utilities.c'],['../_utilities_8h.html#a20cbe188c42de1a2849be3745a2c9e40',1,'buffer_read_increment(void):&#160;Utilities.c']]],
  ['buffer_5fread_5fposition',['buffer_read_position',['../_utilities_8c.html#a8c8c25ea6e552a6e3bd8c550bf8f4732',1,'buffer_read_position(int motor):&#160;Utilities.c'],['../_utilities_8h.html#a8c8c25ea6e552a6e3bd8c550bf8f4732',1,'buffer_read_position(int motor):&#160;Utilities.c']]],
  ['buffer_5fread_5fu',['buffer_read_u',['../_utilities_8c.html#a96d145a44e951f2b6213830490bb45c5',1,'buffer_read_u(int motor):&#160;Utilities.c'],['../_utilities_8h.html#a96d145a44e951f2b6213830490bb45c5',1,'buffer_read_u(int motor):&#160;Utilities.c']]],
  ['buffer_5fwrite',['buffer_write',['../_utilities_8c.html#a0391465d79feefe5cce4385fe8385e6a',1,'buffer_write(int M1_actPos, int M2_actPos, int M1_u, int M2_u):&#160;Utilities.c'],['../_utilities_8h.html#a0391465d79feefe5cce4385fe8385e6a',1,'buffer_write(int M1_actPos, int M2_actPos, int M1_u, int M2_u):&#160;Utilities.c']]]
];
