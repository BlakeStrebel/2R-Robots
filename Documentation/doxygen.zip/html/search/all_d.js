var searchData=
[
  ['safetycheck',['safetyCheck',['../r2r_8c.html#ace09a3c8965a45676cd69533a94e1e99',1,'safetyCheck(void):&#160;r2r.c'],['../r2r_8h.html#ace09a3c8965a45676cd69533a94e1e99',1,'safetyCheck(void):&#160;r2r.c']]],
  ['send_5fdata',['send_data',['../_utilities_8h.html#aa8061654c0af0c3c3fac9e63ed7eaed6',1,'Utilities.c']]],
  ['sensorupdate',['sensorUpdate',['../r2r_8c.html#ad22b938bbd9c44b3de841391716d46b9',1,'sensorUpdate(void):&#160;r2r.c'],['../r2r_8h.html#ad22b938bbd9c44b3de841391716d46b9',1,'sensorUpdate(void):&#160;r2r.c']]],
  ['set_5fdesired_5fangle',['set_desired_angle',['../_control_8h.html#a1849f501c3cb9e99ef17c65881960289',1,'Control.c']]],
  ['set_5fposition_5fgains',['set_position_gains',['../_control_8h.html#aab0c2966059686b7288fceaa8b72d950',1,'Control.c']]],
  ['setadcmux',['setADCMux',['../r2r_8c.html#ab07c8a54a14148ee47eef30ea3baa661',1,'setADCMux(int motor, int number):&#160;r2r.c'],['../r2r_8h.html#ab07c8a54a14148ee47eef30ea3baa661',1,'setADCMux(int motor, int number):&#160;r2r.c']]],
  ['setmode',['setMODE',['../_utilities_8h.html#af4c5a7352334b805d0c36e3b495d0a16',1,'Utilities.c']]],
  ['setn',['setN',['../_utilities_8h.html#acba07f8eaf5cdce3760657cfd53c35b8',1,'Utilities.c']]],
  ['sysinit',['sysInit',['../_system_8h.html#a9708de954e135b89af84d9d82b552667',1,'System.c']]],
  ['system_2eh',['System.h',['../_system_8h.html',1,'']]]
];
