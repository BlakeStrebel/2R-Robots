var searchData=
[
  ['pi_5fcontroller',['PI_controller',['../_current_control_8c.html#af15be4bf8772044edad3aac0661bc2fb',1,'PI_controller(int motor, int reference, int actual):&#160;CurrentControl.c'],['../_current_control_8h.html#af15be4bf8772044edad3aac0661bc2fb',1,'PI_controller(int motor, int reference, int actual):&#160;CurrentControl.c']]],
  ['pwminit',['pwmInit',['../_motor_8h.html#a1c8ae46921c4ae7d57bd44dd994e10bd',1,'Motor.h']]]
];
