var searchData=
[
  ['encoder_5fstates',['encoder_states',['../structencoder__states.html',1,'']]]
];
