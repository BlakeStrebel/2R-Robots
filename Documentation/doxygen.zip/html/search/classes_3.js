var searchData=
[
  ['pid_5fgains',['PID_gains',['../struct_p_i_d__gains.html',1,'']]]
];
